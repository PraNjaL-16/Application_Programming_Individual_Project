console.log('application started')

document.querySelector('.btn').addEventListener('click', ctrlAddItem); 

document.addEventListener('keypress',function(event) {

            if(event.keyCode === 13 || event.which === 13)               
                {
                    ctrlAddItem();
                }

}); 

function getInput() {
    
        return {  
            
        name: document.querySelector('.name').value,                          
        email: document.querySelector('.email').value,        
    }
};

function validateemail()  
{  
    var x=input.email;  
    
    var atposition=x.indexOf("@");  
    var dotposition=x.lastIndexOf(".");  
    if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length)
    {  
    return false;  
    }  
}  

function ctrlAddItem() {                     
    
        input = getInput();
    
        if(input.name === "" && input.email === "")
        {
            alert('fill all the manditaory details');
            return;
        }
        else if(input.name === "" || input.email === "")
        {
            alert('fill all the manditaory details');
            return;
        }
       
        if(validateemail() === false)
            {
                alert("Please enter a valid e-mail address");  
            }
        else
            {
                alert('Thanks! for giving us your time');
            }
        
    };                                                                         

